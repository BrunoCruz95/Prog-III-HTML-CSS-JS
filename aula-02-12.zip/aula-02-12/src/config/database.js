module.exports = {
    dialect: 'mysql',
    port: 3306,
    host: "localhost",
    username: "root",
    password: "FRANCIeMAI123",
    database: 'bancoTeste',
    define: {
        timerstamps: true,
        underscored: true
    }
}