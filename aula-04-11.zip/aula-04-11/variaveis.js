
        var n1 = 10;
        var n2 = 20.3;
        console.log("Soma "+n1+" + "+n2+" = "+(n1+n2));
        console.log("Caraca! Te amo "+ (500 + 500) +" Milhões");

        var nome = 'Bruno';
        var idade = 18;
        var altura = 1.80;
        var peso = 84;
        var aluno = true;
        var disciplina = ['Matemática', 'História', 'Biologia']

    var objetoProf = {
        nome: 'Jobisvaldo',
        idade: 56,
        altura: 1.90,
        disciplinas : {
            disciplina1: 'Programação I',
            disciplina2: 'Programação II',
            disciplina3: 'Programação III'
        }
    }

        console.log('\nNome: '+nome+'\nIdade: '+idade+'\nAltura: '+altura+'\nPeso: '+peso+'\nAluno: '+aluno+'\nDisciplina: '+disciplina)
        console.log('\nNome: '+ objetoProf.nome);

        console.log('\nDisciplina 1: '+ objetoProf.disciplinas.disciplina1);
        console.log('\nDisciplina 2: '+ objetoProf.disciplinas.disciplina2);
        console.log('\nDisciplina 3: '+ objetoProf.disciplinas.disciplina3);