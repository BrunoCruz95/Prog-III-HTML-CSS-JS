
var n1 = 20;
var n2 = 15;

var soma = n1 + n2;
console.log(n1+" + "+n2+" = "+soma);

var sub = n1 - n2;
console.log(n1+" - "+n2+" = "+sub);

var divi = 12 / 2;
console.log(n1+" ÷ "+n2+" = "+divi);

var mult = 12 * 2;
console.log(n1+" x "+n2+" = "+mult);
