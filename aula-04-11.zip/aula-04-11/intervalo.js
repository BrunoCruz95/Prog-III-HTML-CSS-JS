function imprimir(){
    console.log("SHOW")
}
setInterval(imprimir, 1000)