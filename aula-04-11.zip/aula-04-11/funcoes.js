
var soma = function(num1, num2){
    var res = num1 + num2
    return res
}

var res = soma(12, 2)
console.log(res);