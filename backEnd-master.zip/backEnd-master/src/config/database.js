module.exports = {
    dialect: 'mysql',
    port: 3307,
    host: "localhost",
    username:"root",
    password:"123456",
    database: 'bancoTeste',
    define: {
        timerstamps: true,
        underscored: true
    }
}